﻿namespace EvolApp.API.Models
{
    public class EmpresaLoginRequest
    {
        public string Cuit { get; set; }
        public string Usuario { get; set; }
        public string Clave { get; set; }
    }
}
