﻿namespace EvolApp.API.Models
{
    public class EmpresaLoginResponse
    {
        public string Nombre { get; set; }
        public string Url { get; set; }
    }
}
